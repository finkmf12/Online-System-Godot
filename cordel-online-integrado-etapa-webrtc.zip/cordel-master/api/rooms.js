const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_KEY = process.env.SUPABASE_PUBLISHABLE_KEY;

function reply(res, status, body) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  res.setHeader("Cache-Control", "no-store");
  return res.status(status).json(body);
}

function bodyOf(req) {
  if (req.body && typeof req.body === "object") return req.body;
  if (typeof req.body === "string") {
    try { return JSON.parse(req.body); } catch (_) { return {}; }
  }
  return {};
}

async function rpc(name, args = {}) {
  if (!SUPABASE_URL || !SUPABASE_KEY) throw new Error("API não configurada.");
  const response = await fetch(`${SUPABASE_URL}/rest/v1/rpc/${name}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      apikey: SUPABASE_KEY,
      Authorization: `Bearer ${SUPABASE_KEY}`,
    },
    body: JSON.stringify(args),
  });
  const text = await response.text();
  let data;
  try { data = text ? JSON.parse(text) : null; } catch (_) { data = text; }
  if (!response.ok) {
    const error = new Error(
      typeof data === "object" && data
        ? (data.message || data.details || data.hint || "Falha no banco de dados.")
        : "Falha no banco de dados."
    );
    error.status = response.status >= 500 ? 502 : 400;
    throw error;
  }
  return data;
}

module.exports = async function handler(req, res) {
  if (req.method === "OPTIONS") return reply(res, 204, {});
  try {
    if (req.method === "GET") {
      return reply(res, 200, { ok: true, data: await rpc("cordel_list_rooms") });
    }
    if (req.method !== "POST") return reply(res, 405, { ok: false, error: "Use GET ou POST." });

    const b = bodyOf(req);
    let data;
    switch (b.action) {
      case "list":
        data = await rpc("cordel_list_rooms");
        break;
      case "create":
        data = await rpc("cordel_create_room", {
          p_nickname: b.nickname,
          p_max_players: Number(b.max_players || 5),
        });
        break;
      case "join":
        data = await rpc("cordel_join_room", {
          p_room_code: b.room_code,
          p_nickname: b.nickname,
        });
        break;
      case "state":
        data = await rpc("cordel_room_state_token", {
          p_room_id: b.room_id,
          p_member_id: b.member_id,
          p_player_token: b.player_token,
        });
        break;
      case "leave":
        data = await rpc("cordel_leave_room_token", {
          p_room_id: b.room_id,
          p_member_id: b.member_id,
          p_player_token: b.player_token,
        });
        break;
      case "start":
        data = await rpc("cordel_start_room", {
          p_room_id: b.room_id,
          p_member_id: b.member_id,
          p_player_token: b.player_token,
        });
        break;
      case "signal":
        data = await rpc("cordel_send_signal", {
          p_room_id: b.room_id,
          p_member_id: b.member_id,
          p_player_token: b.player_token,
          p_to_member_id: b.to_member_id,
          p_kind: b.kind,
          p_payload: b.payload,
        });
        break;
      case "poll":
        data = await rpc("cordel_poll_signals", {
          p_room_id: b.room_id,
          p_member_id: b.member_id,
          p_player_token: b.player_token,
          p_since: b.since || "1970-01-01T00:00:00Z",
        });
        break;
      case "heartbeat":
        data = await rpc("cordel_heartbeat", {
          p_room_id: b.room_id,
          p_member_id: b.member_id,
          p_player_token: b.player_token,
        });
        break;
      default:
        return reply(res, 400, { ok: false, error: "Ação inválida." });
    }
    return reply(res, 200, { ok: true, data });
  } catch (error) {
    return reply(res, error.status || 500, { ok: false, error: error.message || "Erro interno." });
  }
};
