# Instala a extensão WebRTC nativa oficial para Godot 4.3+.
# Execute uma vez no Windows, antes de abrir o projeto no Godot.
$ErrorActionPreference = 'Stop'
$Version = '1.2.2-stable'
$Url = "https://github.com/godotengine/webrtc-native/releases/download/$Version/godot-extension-webrtc_native.zip"
$ExpectedSha256 = '98e9446921740d995bd9ca1be48798dc3c2ceed51e044a25ce18b3cff11f56e5'
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectRoot = Split-Path -Parent $ScriptDir
$GodotDir = Join-Path $ProjectRoot 'godot'
$TempZip = Join-Path $env:TEMP 'cordel-webrtc-native.zip'

try {
    if (-not (Test-Path (Join-Path $GodotDir 'project.godot'))) {
        throw "Não encontrei godot/project.godot. Extraia o ZIP completo do Cordel antes de executar este instalador."
    }
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Write-Host 'Baixando a extensão WebRTC oficial para Godot 4.3+...' -ForegroundColor Cyan
    Invoke-WebRequest -Uri $Url -OutFile $TempZip -UseBasicParsing

    $Hash = (Get-FileHash -Path $TempZip -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($Hash -ne $ExpectedSha256) {
        throw 'A verificação SHA-256 falhou. O arquivo baixado não corresponde ao lançamento oficial esperado.'
    }

    Write-Host 'Verificação concluída. Instalando os arquivos no projeto Godot...' -ForegroundColor Cyan
    Expand-Archive -Path $TempZip -DestinationPath $GodotDir -Force
    $Extension = Get-ChildItem -Path $GodotDir -Recurse -Filter '*.gdextension' | Select-Object -First 1
    if (-not $Extension) {
        throw 'O ZIP foi extraído, mas não encontrei o arquivo .gdextension.'
    }
    Write-Host 'WebRTC instalado com sucesso!' -ForegroundColor Green
    Write-Host "Arquivo encontrado: $($Extension.FullName)"
    Write-Host 'Agora abra godot/project.godot no Godot 4.3 ou superior.' -ForegroundColor Yellow
}
catch {
    Write-Host "ERRO: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
finally {
    if (Test-Path $TempZip) { Remove-Item $TempZip -Force }
}
