# Cordel Online — API Vercel + Supabase

API de salas e sinalização WebRTC hospedada na Vercel. O tráfego de jogo não passa pela API: ela apenas cria salas, registra jogadores e encaminha as mensagens de sinalização para estabelecer conexões WebRTC diretas entre os jogadores.

## API publicada

Base URL: `https://cordel-online-api.vercel.app`

- `GET /api/health` — verifica disponibilidade.
- `GET /api/rooms` — lista salas aguardando jogadores.
- `POST /api/rooms` — recebe um JSON com `action`.

Ações POST: `list`, `create`, `join`, `state`, `leave`, `start`, `signal`, `poll`, `heartbeat`.

Exemplo para criar sala:

```json
{
  "action": "create",
  "nickname": "Jogador",
  "max_players": 4
}
```

Exemplo para entrar:

```json
{
  "action": "join",
  "room_code": "ABC123",
  "nickname": "Convidado"
}
```

As respostas de `create` e `join` entregam um `player_token`. O jogo deve guardar esse token localmente durante a sessão e enviá-lo nas operações autenticadas da sala. Não o compartilhe no chat nem o grave em logs.

## Variáveis da Vercel

O projeto `cordel-online-api` já possui estas variáveis criptografadas nos ambientes Production, Preview e Development:

- `SUPABASE_URL`
- `SUPABASE_PUBLISHABLE_KEY`

Não coloque chaves secret/service-role no executável do jogo ou no repositório.

## Limites atuais

- Salas configuráveis para 2 a 4 jogadores.
- Expiração inicial de sala: 2 horas.
- Sinalização aceita `offer`, `answer` e `ice`.
- A API não retransmite pacotes do jogo; a intenção é WebRTC peer-to-peer. A sinalização é armazenada temporariamente no banco para troca de SDP/ICE.
- O jogo Godot ainda precisa da camada WebRTC para substituir o transporte ENet fora da LAN. Os RPCs e a lógica de gameplay não devem ser removidos durante essa adaptação.

## Observação

A API foi publicada e o endpoint de saúde e a listagem GET foram testados. As rotinas SQL de criação e entrada em sala também foram testadas diretamente no banco. A integração POST completa e o multiplayer WebRTC no Godot ainda precisam ser testados com o cliente do jogo.
