# Cordel Online — etapa WebRTC

## Infraestrutura

- API pública: `https://cordel-online-api.vercel.app/api/rooms`
- Banco e sinalização: Supabase `Cordel-Online`
- Transporte do jogo: WebRTC direto entre o anfitrião e cada convidado.
- Limite: 5 jogadores contando o anfitrião.
- LAN/ENet continua disponível como alternativa local.

## Requisito no Windows

O projeto usa Godot 4.3. As classes WebRTC precisam da extensão nativa em exportações desktop.

1. Extraia o projeto completo.
2. Abra a pasta `instalador`.
3. Clique com o botão direito em `instalar_webrtc.ps1` e escolha **Executar com PowerShell**. Se o Windows bloquear a execução, abra o PowerShell nessa pasta e rode `powershell -ExecutionPolicy Bypass -File .\instalar_webrtc.ps1`.
4. O instalador baixa a versão oficial `webrtc-native 1.2.2-stable`, confere o SHA-256 e extrai a extensão dentro da pasta `godot`.
5. Abra `godot/project.godot` no Godot 4.3 ou superior.

## Como jogar online

1. No menu do Cordel, abra **CO-OP ONLINE / LAN**.
2. O anfitrião informa o nome do mundo e seu nome e clica em **HOSPEDAR ONLINE**.
3. Compartilha o código de seis caracteres com os amigos.
4. Os convidados digitam seus nomes e o código e clicam em **ENTRAR ONLINE**.
5. Quando todos aparecerem como conectados, o anfitrião clica em **COMEÇAR**.

## Limitações conhecidas desta etapa

- A sinalização SDP/ICE passa pela API Vercel e pelo Supabase; os pacotes de jogo não passam pela Vercel.
- Não há servidor STUN ou TURN externo nesta configuração, para manter a infraestrutura restrita à Vercel e ao Supabase. Isso limita bastante a travessia de NAT: conexões pela internet só funcionarão quando os endereços ICE dos computadores forem alcançáveis diretamente (por exemplo, IPv6 público com firewall permitindo UDP). Redes com NAT/CGNAT normalmente não conseguirão conectar; a LAN continua funcionando.
- A primeira implementação mantém o modelo atual de autoridade do anfitrião. Ela não altera a lógica de sincronização de inimigos, objetos, dano, XP e moedas do jogo.
- A compilação e o teste de duas instâncias reais precisam ser feitos no Windows com Godot 4.3+ e a extensão instalada. Este ambiente não possui o editor Godot nem a biblioteca nativa para validar uma partida real.
