extends Node
# Rede: a base do co-op por LAN (rede local), até 5 pessoas — 1 anfitrião + 4 convidados.
# Autoload (acessa-se por "Rede" de qualquer script). Usa o sistema de multiplayer de alto nível do Godot (ENet).
#
# ESTADO DE VERDADE (pra não enganar ninguém): isso aqui já conecta de verdade — bicho, chefe (de fase e a Cuca
# do portal), mapa (pote/baú/oratório/loja/portal/gente), dano, XP e moeda já são compartilhados de verdade
# (autoridade do anfitrião, ver World.gd). O que AINDA NÃO FOI FEITO: a carta de nível de cada um não aparece
# visualmente pro parceiro (hoje cada um ainda sobe sozinho, sem avisar o outro — funciona, só não é visto).

const PORTA := 7777
const API_CORDEL := "https://cordel-online-api.vercel.app/api/rooms"
const MAX_JOGADORES := 5     # contando o anfitrião
const PORTA_DESCOBERTA := 7778   # UDP à parte, só pra anunciar/achar mundo hospedado na rede local

var _udp_escuta: PacketPeerUDP    # sempre ligado: escuta quem está anunciando mundo na rede
var _udp_anuncio: PacketPeerUDP  # só quando eu sou o anfitrião: manda o anúncio
var _anuncio_t := 0.0
var _nome_mundo_host := ""
var mundos_vistos := {}          # ip (String) -> {"nome": String, "visto": float}
signal mundos_mudaram()
signal sala_atualizada()

var heroi_por_id := {}       # peer_id (int) -> id da classe escolhida por essa pessoa
var nome_por_id := {}        # peer_id (int) -> nome que a pessoa digitou
var _ligado := false         # o Godot sempre bota um "OfflineMultiplayerPeer" por padrão, então
var online_ativo := false
var online_codigo := ""
var online_jogadores: Array = []
var online_max_players := 5
var _online_room_id := ""
var _online_member_id := ""
var _online_token := ""
var _online_peer_id := 0
var _online_timer := 0.0
var _online_busy := false
var _ultimo_sinal := "1970-01-01T00:00:00Z"
var _webrtc_peer: WebRTCMultiplayerPeer
var _webrtc_conexoes := {} # peer_id -> WebRTCPeerConnection
                              # não dá pra usar "multiplayer_peer != null" pra saber se o co-op tá de verdade ligado

signal entrou(id: int)
signal saiu(id: int)
signal partida_comecou()
signal falhou(motivo: String)

func _ready() -> void:
	multiplayer.peer_connected.connect(func(id):
		entrou.emit(id)
		if sou_host(): _mandar_mundo.rpc_id(id, Salvo.d))     # novo convidado: recebe o progresso deste mundo emprestado
	multiplayer.peer_disconnected.connect(func(id):
		heroi_por_id.erase(id); nome_por_id.erase(id); saiu.emit(id))
	multiplayer.connection_failed.connect(_ao_falhar_conexao)
	multiplayer.server_disconnected.connect(_ao_servidor_desconectado)
	_udp_escuta = PacketPeerUDP.new()
	if _udp_escuta.bind(PORTA_DESCOBERTA) != OK: _udp_escuta = null   # porta já em uso (ex.: 2 instâncias no mesmo PC) — sem problema, só não descobre sozinho

func _ao_falhar_conexao() -> void:
	if online_ativo:
		falhou.emit("A conexão direta com o anfitrião falhou. A rede pode estar bloqueando WebRTC/UDP.")
	else:
		_ligado = false
		Salvo.sair_mundo()
		falhou.emit("Não consegui conectar. Confira o endereço e se os dois estão na mesma rede.")

func _ao_servidor_desconectado() -> void:
	if online_ativo:
		_ligado = false
		_limpar_online()
		Salvo.sair_mundo()
		falhou.emit("O anfitrião saiu da sala.")
	else:
		_ligado = false
		Salvo.sair_mundo()
		falhou.emit("O anfitrião saiu da sala.")

func _process(delta: float) -> void:
	if online_ativo:
		_online_timer -= delta
		if _online_timer <= 0.0 and not _online_busy:
			_online_timer = 1.5
			_atualizar_online.call_deferred()
	if ativo() and sou_host() and not online_ativo:
		_anuncio_t -= delta
		if _anuncio_t <= 0.0: _anuncio_t = 1.5; _anunciar()
	_escutar_anuncios()
	var agora := Time.get_ticks_msec() / 1000.0
	for ip in mundos_vistos.keys().duplicate():
		if agora - mundos_vistos[ip]["visto"] > 4.0: mundos_vistos.erase(ip); mundos_mudaram.emit()

func _anunciar() -> void:
	if _udp_anuncio == null:
		_udp_anuncio = PacketPeerUDP.new()
		_udp_anuncio.set_broadcast_enabled(true)
		_udp_anuncio.set_dest_address("255.255.255.255", PORTA_DESCOBERTA)
	_udp_anuncio.put_packet(("CORDEL_MUNDO:" + _nome_mundo_host).to_utf8_buffer())

func _escutar_anuncios() -> void:
	if _udp_escuta == null: return
	while _udp_escuta.get_available_packet_count() > 0:
		var pct := _udp_escuta.get_packet()
		var ip := _udp_escuta.get_packet_ip()
		var txt := pct.get_string_from_utf8()
		if txt.begins_with("CORDEL_MUNDO:") and ip != "":
			var nome := txt.substr(17)
			var novo := not mundos_vistos.has(ip)
			mundos_vistos[ip] = {"nome": nome, "visto": Time.get_ticks_msec() / 1000.0}
			if novo: mundos_mudaram.emit()

@rpc("authority", "call_remote", "reliable")
func _mandar_mundo(dados: Dictionary) -> void:
	Salvo.entrar_mundo_visitante(dados)

func hospedar(nome_mundo: String) -> String:
	if nome_mundo.strip_edges() == "": return "Dê um nome para o seu mundo."
	online_ativo = false
	var peer := ENetMultiplayerPeer.new()
	var erro := peer.create_server(PORTA, MAX_JOGADORES - 1)
	if erro != OK: return "Não consegui abrir a porta %d (erro %d). Outro programa já está usando ela?" % [PORTA, erro]
	multiplayer.multiplayer_peer = peer
	_ligado = true
	_nome_mundo_host = nome_mundo.strip_edges()
	Salvo.entrar_mundo(_nome_mundo_host)
	heroi_por_id.clear(); nome_por_id.clear()
	return ""

func entrar(ip: String) -> String:
	if ip.strip_edges() == "": return "Digite o endereço de quem hospedou."
	online_ativo = false
	var peer := ENetMultiplayerPeer.new()
	var erro := peer.create_client(ip.strip_edges(), PORTA)
	if erro != OK: return "Endereço inválido."
	multiplayer.multiplayer_peer = peer
	_ligado = true
	heroi_por_id.clear(); nome_por_id.clear()
	return ""

func sair() -> void:
	if online_ativo:
		var credenciais := _credenciais_online()
		_avisar_saida_online.call_deferred(credenciais)
		online_ativo = false
	if multiplayer.multiplayer_peer: multiplayer.multiplayer_peer.close()
	multiplayer.multiplayer_peer = null
	_ligado = false
	_nome_mundo_host = ""
	if _udp_anuncio: _udp_anuncio.close(); _udp_anuncio = null
	_webrtc_conexoes.clear()
	_webrtc_peer = null
	online_codigo = ""; online_jogadores.clear()
	_online_room_id = ""; _online_member_id = ""; _online_token = ""; _online_peer_id = 0
	Salvo.sair_mundo()
	heroi_por_id.clear(); nome_por_id.clear()

# ---------------- multiplayer online (WebRTC direto + sinalização Vercel/Supabase) ----------------
# Sem STUN/TURN externo: a conexão direta só funciona quando os endereços ICE locais já são alcançáveis.
func _api_online(acao: String, dados: Dictionary = {}) -> Dictionary:
	var pedido := HTTPRequest.new()
	pedido.timeout = 12.0
	add_child(pedido)
	var corpo := dados.duplicate(true)
	corpo["action"] = acao
	var erro := pedido.request(API_CORDEL, ["Content-Type: application/json"], HTTPClient.METHOD_POST, JSON.stringify(corpo))
	if erro != OK:
		pedido.queue_free()
		return {"ok": false, "error": "Não consegui acessar a API do Cordel (erro %d)." % erro}
	var resposta: Array = await pedido.request_completed
	pedido.queue_free()
	var codigo: int = resposta[1]
	var texto: String = resposta[3].get_string_from_utf8()
	var json: Variant = JSON.parse_string(texto)
	if codigo < 200 or codigo >= 300 or typeof(json) != TYPE_DICTIONARY or not json.get("ok", false):
		var msg := "Falha na comunicação com o Cordel Online."
		if typeof(json) == TYPE_DICTIONARY: msg = String(json.get("error", msg))
		return {"ok": false, "error": msg}
	return {"ok": true, "data": json.get("data", {})}

func hospedar_online(nome_mundo: String, nome_jogador: String) -> String:
	if nome_mundo.strip_edges() == "": return "Dê um nome para o seu mundo."
	if nome_jogador.strip_edges() == "": return "Digite seu nome."
	if not ClassDB.class_exists("WebRTCMultiplayerPeer") or not ClassDB.class_exists("WebRTCPeerConnection"):
		return "O componente WebRTC ainda não está instalado. Execute o instalador instalar_webrtc.ps1 na pasta do projeto."
	var resposta := await _api_online("create", {"nickname": nome_jogador.strip_edges(), "max_players": MAX_JOGADORES})
	if not resposta.ok: return String(resposta.get("error", "Não foi possível criar a sala."))
	_configurar_sala_online(resposta.data)
	var erro := _iniciar_webrtc(true)
	if erro != "":
		await _api_online("leave", _credenciais_online())
		_limpar_online()
		return erro
	_nome_mundo_host = nome_mundo.strip_edges()
	Salvo.entrar_mundo(_nome_mundo_host)
	return ""

func entrar_online(codigo: String, nome_jogador: String) -> String:
	if codigo.strip_edges() == "": return "Digite o código da sala."
	if nome_jogador.strip_edges() == "": return "Digite seu nome."
	if not ClassDB.class_exists("WebRTCMultiplayerPeer") or not ClassDB.class_exists("WebRTCPeerConnection"):
		return "O componente WebRTC ainda não está instalado. Execute o instalador instalar_webrtc.ps1 na pasta do projeto."
	var resposta := await _api_online("join", {"room_code": codigo.strip_edges().to_upper(), "nickname": nome_jogador.strip_edges()})
	if not resposta.ok: return String(resposta.get("error", "Não foi possível entrar na sala."))
	_configurar_sala_online(resposta.data)
	var erro := _iniciar_webrtc(false)
	if erro != "":
		await _api_online("leave", _credenciais_online())
		_limpar_online()
		return erro
	return ""

func _configurar_sala_online(dados: Dictionary) -> void:
	_online_room_id = String(dados.get("room_id", ""))
	_online_member_id = String(dados.get("member_id", ""))
	_online_token = String(dados.get("player_token", ""))
	_online_peer_id = int(dados.get("peer_id", 0))
	online_max_players = int(dados.get("max_players", MAX_JOGADORES))
	online_codigo = String(dados.get("room_code", ""))
	online_jogadores.clear()
	_ultimo_sinal = "1970-01-01T00:00:00Z"
	heroi_por_id.clear(); nome_por_id.clear()

func _credenciais_online() -> Dictionary:
	return {"room_id": _online_room_id, "member_id": _online_member_id, "player_token": _online_token}

func _iniciar_webrtc_host() -> String:
	_webrtc_peer = WebRTCMultiplayerPeer.new()
	var erro := _webrtc_peer.create_server()
	if erro != OK: return "Não consegui iniciar o multiplayer WebRTC (erro %d)." % erro
	multiplayer.multiplayer_peer = _webrtc_peer
	_ligado = true
	return ""

func _iniciar_webrtc(servidor: bool) -> String:
	if servidor:
		var erro_host := _iniciar_webrtc_host()
		if erro_host != "": return erro_host
	else:
		_webrtc_peer = WebRTCMultiplayerPeer.new()
		var erro_cliente := _webrtc_peer.create_client(_online_peer_id)
		if erro_cliente != OK: return "Não consegui iniciar o cliente WebRTC (erro %d)." % erro_cliente
		multiplayer.multiplayer_peer = _webrtc_peer
		_ligado = true
	online_ativo = true
	_online_timer = 0.1
	return ""

func _criar_conexao_webrtc(peer_id: int, criar_oferta: bool) -> void:
	if _webrtc_peer == null or _webrtc_conexoes.has(peer_id): return
	var conexao := WebRTCPeerConnection.new()
	var erro := conexao.initialize({"iceServers": []})
	if erro != OK:
		falhou.emit("Não consegui preparar a conexão WebRTC (erro %d)." % erro)
		return
	conexao.session_description_created.connect(_on_sessao_criada.bind(peer_id))
	conexao.ice_candidate_created.connect(_on_candidato_ice.bind(peer_id))
	var adicionado := _webrtc_peer.add_peer(conexao, peer_id)
	if adicionado != OK:
		falhou.emit("Não consegui adicionar o jogador à conexão WebRTC (erro %d)." % adicionado)
		return
	_webrtc_conexoes[peer_id] = conexao
	if criar_oferta:
		conexao.create_offer()

func _on_sessao_criada(tipo: String, sdp: String, peer_id: int) -> void:
	if not _webrtc_conexoes.has(peer_id): return
	var conexao: WebRTCPeerConnection = _webrtc_conexoes[peer_id]
	conexao.set_local_description(tipo, sdp)
	var destino := _member_id_por_peer(peer_id)
	if destino == "": return
	var tipo_sinal := "offer" if tipo == "offer" else "answer"
	_api_online("signal", _credenciais_online().merged({
		"to_member_id": destino, "kind": tipo_sinal, "payload": {"sdp": sdp}
	}, true))

func _on_candidato_ice(mid: String, indice: int, sdp: String, peer_id: int) -> void:
	var destino := _member_id_por_peer(peer_id)
	if destino == "": return
	_api_online("signal", _credenciais_online().merged({
		"to_member_id": destino, "kind": "ice",
		"payload": {"mid": mid, "index": indice, "sdp": sdp}
	}, true))

func _member_id_por_peer(peer_id: int) -> String:
	for jogador in online_jogadores:
		if int(jogador.get("peer_id", -1)) == peer_id:
			return String(jogador.get("member_id", ""))
	return ""

func _peer_id_por_member(member_id: String) -> int:
	for jogador in online_jogadores:
		if String(jogador.get("member_id", "")) == member_id:
			return int(jogador.get("peer_id", 0))
	return 0

func _atualizar_online() -> void:
	if not online_ativo or _online_busy: return
	_online_busy = true
	var estado := await _api_online("state", _credenciais_online())
	if estado.ok:
		var dados: Dictionary = estado.data
		if String(dados.get("status", "")) == "closed":
			_online_busy = false
			sair()
			falhou.emit("A sala foi encerrada pelo anfitrião.")
			return
		var jogadores_anteriores := online_jogadores.duplicate(true)
		online_jogadores = dados.get("players", [])
		if jogadores_anteriores != online_jogadores: sala_atualizada.emit()
		for jogador in online_jogadores:
			var ja_estava := false
			for antigo in jogadores_anteriores:
				if String(antigo.get("member_id", "")) == String(jogador.get("member_id", "")): ja_estava = true
			if not ja_estava and int(jogador.get("peer_id", 0)) != _online_peer_id:
				entrou.emit(int(jogador.get("peer_id", 0)))
		for antigo in jogadores_anteriores:
			var ainda_esta := false
			for atual in online_jogadores:
				if String(atual.get("member_id", "")) == String(antigo.get("member_id", "")): ainda_esta = true
			if not ainda_esta:
				var id_antigo := int(antigo.get("peer_id", 0))
				if _webrtc_conexoes.has(id_antigo):
					_webrtc_peer.remove_peer(id_antigo)
					_webrtc_conexoes.erase(id_antigo)
				saiu.emit(id_antigo)
		for jogador in online_jogadores:
			var id := int(jogador.get("peer_id", 0))
			if id != _online_peer_id and (sou_host() or id == 1) and not _webrtc_conexoes.has(id):
				_criar_conexao_webrtc(id, not sou_host() and id == 1)
	else:
		_online_busy = false
		falhou.emit(String(estado.get("error", "A sala online perdeu contato com o servidor.")))
		return
	var sinais := await _api_online("poll", _credenciais_online().merged({"since": _ultimo_sinal}, true))
	if sinais.ok and typeof(sinais.data) == TYPE_ARRAY:
		for sinal in sinais.data:
			var criado := String(sinal.get("created_at", ""))
			if criado > _ultimo_sinal: _ultimo_sinal = criado
			_processar_sinal(sinal)
	_online_busy = false

func _processar_sinal(sinal: Dictionary) -> void:
	var origem := String(sinal.get("from_member_id", ""))
	var peer_id := _peer_id_por_member(origem)
	if peer_id <= 0 or not _webrtc_conexoes.has(peer_id): return
	var conexao: WebRTCPeerConnection = _webrtc_conexoes[peer_id]
	var payload: Dictionary = sinal.get("payload", {})
	match String(sinal.get("kind", "")):
		"offer": conexao.set_remote_description("offer", String(payload.get("sdp", "")))
		"answer": conexao.set_remote_description("answer", String(payload.get("sdp", "")))
		"ice": conexao.add_ice_candidate(String(payload.get("mid", "")), int(payload.get("index", 0)), String(payload.get("sdp", "")))

func _avisar_saida_online(credenciais: Dictionary) -> void:
	if not credenciais.is_empty():
		await _api_online("leave", credenciais)

func _limpar_online() -> void:
	online_ativo = false
	_ligado = false
	_webrtc_conexoes.clear()
	_webrtc_peer = null
	online_codigo = ""; online_jogadores.clear()
	_online_room_id = ""; _online_member_id = ""; _online_token = ""; _online_peer_id = 0

func listar_salas_online() -> Array:
	var resposta := await _api_online("list")
	if not resposta.ok: return []
	return resposta.data if typeof(resposta.data) == TYPE_ARRAY else []

func ativo() -> bool:
	return _ligado

func sou_host() -> bool:
	return ativo() and multiplayer.is_server()

func meu_id() -> int:
	return multiplayer.get_unique_id()

# todo mundo conectado (inclusive eu), sempre na mesma ordem em todas as máquinas
func ids() -> Array:
	if not ativo(): return [meu_id()]
	var r: Array = multiplayer.get_peers()
	r.append(meu_id())
	r.sort()
	return r

# endereços desta máquina na rede local (pra mostrar pro anfitrião passar pros amigos)
static func meus_enderecos() -> Array:
	var r := []
	for ip in IP.get_local_addresses():
		if ip.begins_with("192.168.") or ip.begins_with("10.") or ip.begins_with("172."):
			r.append(ip)
	return r

# mundos hospedados vistos agora na rede local, pra listar na tela de entrar em vez de pedir o IP na mão
func mundos_disponiveis() -> Array:
	var r := []
	for ip in mundos_vistos: r.append({"ip": ip, "nome": mundos_vistos[ip]["nome"]})
	r.sort_custom(func(a, b): return a["nome"] < b["nome"])
	return r

@rpc("any_peer", "call_local", "reliable")
func _apresentar(id: int, heroi: String, nome: String) -> void:
	heroi_por_id[id] = heroi
	nome_por_id[id] = nome if nome.strip_edges() != "" else ("Jogador %d" % (ids().find(id) + 1))

func apresentar_se(heroi: String, nome: String) -> void:
	_apresentar.rpc(meu_id(), heroi, nome)

@rpc("authority", "call_local", "reliable")
func _comecar() -> void:
	partida_comecou.emit()

# só o anfitrião manda começar, pra todo mundo ao mesmo tempo
func comecar() -> void:
	if not sou_host(): return
	if online_ativo:
		var resposta := await _api_online("start", _credenciais_online())
		if not resposta.ok:
			falhou.emit(String(resposta.get("error", "Não consegui iniciar a sala.")))
			return
	_comecar.rpc()
